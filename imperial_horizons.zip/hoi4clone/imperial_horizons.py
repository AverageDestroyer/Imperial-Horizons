import pygame
import sys
import os
from datetime import datetime, timedelta

class RTSGame:
    def __init__(self):
        # Initialization & Setup
        pygame.init()
        # Enable key repeat so backspace can be held down
        pygame.key.set_repeat(300, 50)
        self.SCREEN_WIDTH, self.SCREEN_HEIGHT = 1280, 720
        self.screen = pygame.display.set_mode((self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
        pygame.display.set_caption("RTS Game Prototype")
        self.clock = pygame.time.Clock()

        # Fonts
        self.font = pygame.font.SysFont("Arial", 18)
        self.menu_font = pygame.font.SysFont("Arial", 32)
        self.button_font = pygame.font.SysFont("Arial", 16)
        self.info_font = pygame.font.SysFont("Arial", 14)

        # Global State Variables
        # states: main_menu, settings, load_game, new_game, more_countries, scenarios, in_game
        self.current_state = "main_menu"  
        self.selected_country = None
        self.hovered_country = None
        self.spectator_mode = False

        # Settings
        self.fps_setting = 60
        self.sound_setting = 50
        self.music_setting = 50
        self.is_fullscreen = False
        self.button_cooldown = 0.0
        self.temp_fps = self.fps_setting
        self.temp_sound = self.sound_setting
        self.temp_music = self.music_setting
        self.temp_fullscreen = self.is_fullscreen

        # In-Game Variables
        self.zoom = 1.0
        # Now load the map from the Scenario folder using the 2021_scenario_map filename.
        self.map_image = self.load_image(os.path.join("Scenario", "2021_scenario_map.png"), alpha=False)
        computed_min_zoom = max(self.SCREEN_WIDTH / self.map_image.get_width(),
                                self.SCREEN_HEIGHT / self.map_image.get_height())
        MIN_ZOOM_ALLOWED = 0.5
        self.MIN_ZOOM = max(computed_min_zoom, MIN_ZOOM_ALLOWED)
        if self.zoom < self.MIN_ZOOM:
            self.zoom = self.MIN_ZOOM
        self.camera_x, self.camera_y = 0, 0
        self.ZOOM_SPEED = 0.1
        self.PAN_SPEED = 10
        self.last_zoom = self.zoom
        self.cached_scaled_map = pygame.transform.scale(
            self.map_image,
            (int(self.map_image.get_width() * self.zoom),
             int(self.map_image.get_height() * self.zoom))
        )
        self.sim_time = datetime(2021, 1, 1)
        self.time_multiplier_state = 1
        self.multiplier_mapping = {1: 1, 2: 2, 3: 4, 4: 6, 5: 8}
        self.paused = False
        self.top_bar_height = 40

        # Selection variables (for in-game drag-select)
        self.selecting = False
        self.selection_start = None
        self.selection_rect = None

        if not os.path.exists("save"):
            os.mkdir("save")

        # Resource Loading (icons, backgrounds, etc.)
        self.load_resources()

        # Country Information (for new game screen)
        self.country_info = {
            "United States": "Selected Country: United States\nIdeology: Conservative/Liberal\nEconomic Faction(s): USMCA, Chip 4, IPEF\nMilitaristic Faction(s): NATO\nMilitary Strength: #1\nTechnological Strength: #1\nEconomic Strength: #1\nManpower: 3M (Active) - 1M (Reserve)\nProvinces: To be Decided\nStarting Factories: 22",
            "China": "Selected Country: China\nIdeology: Communist\nEconomic Faction(s): BRICS, SCO\nMilitaristic Faction(s): none\nMilitary Strength: #2\nTechnological Strength: #2\nEconomic Strength: #2\nManpower: 4M (Active) - 2.5M (Reserve)\nProvinces: To be Decided\nStarting Factories: 16",
            "Russia": "Selected Country: Russia\nIdeology: Federal Democracy/Putinism/Authoritarian\nEconomic Faction(s): EEU, CIS, SCO, BRICS, Union of Russia & Belarus\nMilitaristic Faction(s): CSTO\nMilitary Strength: #3\nTechnological Strength: #3\nEconomic Strength: #3\nManpower: 2M (Active) - 2.5M (Reserve)\nProvinces: To Be Decided\nStarting Factories: 18",
            "India": "Selected Country: India\nIdeology: non-aligned\nEconomic Faction(s): BRICS\nMilitaristic Faction(s): None\nMilitary Strength: #4\nTechnological Strength: #7\nEconomic Strength: #5\nManpower: 3M (Active) - 2.8M (Reserve)\nProvinces: To Be Decided\nStarting Factories: 8",
            "United Kingdom": "Selected Country: United Kingdom\nIdeology: Constitutional Monarchy\nEconomic Faction(s): OECD, G-7, G-20\nMilitaristic Faction(s): NATO\nMilitary Strength: #5\nTechnological Strength: #4\nEconomic Strength: #4\nManpower: 1M (Active) - 1.2M (Reserve)\nProvinces: To Be Decided\nStarting Factories: 13"
        }

        # For the More Countries sub-menu:
        self.search_text = ""
        # Complete list of 2021 countries (193 UN member states) plus selected disputed entities.
        # Note: Palestine (a non-member observer state in 2021) is now included.
        self.all_countries = [
            {"code": "Afghanistan", "label": "Afghanistan"},
            {"code": "Albania", "label": "Albania"},
            {"code": "Algeria", "label": "Algeria"},
            {"code": "Andorra", "label": "Andorra"},
            {"code": "Angola", "label": "Angola"},
            {"code": "Antigua and Barbuda", "label": "Antigua and Barbuda"},
            {"code": "Argentina", "label": "Argentina"},
            {"code": "Armenia", "label": "Armenia"},
            {"code": "Australia", "label": "Australia"},
            {"code": "Austria", "label": "Austria"},
            {"code": "Azerbaijan", "label": "Azerbaijan"},
            {"code": "Bahamas", "label": "Bahamas"},
            {"code": "Bahrain", "label": "Bahrain"},
            {"code": "Bangladesh", "label": "Bangladesh"},
            {"code": "Barbados", "label": "Barbados"},
            {"code": "Belarus", "label": "Belarus"},
            {"code": "Belgium", "label": "Belgium"},
            {"code": "Belize", "label": "Belize"},
            {"code": "Benin", "label": "Benin"},
            {"code": "Bhutan", "label": "Bhutan"},
            {"code": "Bolivia", "label": "Bolivia"},
            {"code": "Bosnia and Herzegovina", "label": "Bosnia and Herzegovina"},
            {"code": "Botswana", "label": "Botswana"},
            {"code": "Brazil", "label": "Brazil"},
            {"code": "Brunei", "label": "Brunei"},
            {"code": "Bulgaria", "label": "Bulgaria"},
            {"code": "Burkina Faso", "label": "Burkina Faso"},
            {"code": "Burundi", "label": "Burundi"},
            {"code": "Cabo Verde", "label": "Cabo Verde"},
            {"code": "Cambodia", "label": "Cambodia"},
            {"code": "Cameroon", "label": "Cameroon"},
            {"code": "Canada", "label": "Canada"},
            {"code": "Central African Republic", "label": "Central African Republic"},
            {"code": "Chad", "label": "Chad"},
            {"code": "Chile", "label": "Chile"},
            {"code": "China", "label": "China"},
            {"code": "Colombia", "label": "Colombia"},
            {"code": "Comoros", "label": "Comoros"},
            {"code": "Congo (Brazzaville)", "label": "Congo (Brazzaville)"},
            {"code": "Congo (Kinshasa)", "label": "Congo (Kinshasa)"},
            {"code": "Costa Rica", "label": "Costa Rica"},
            {"code": "Côte d'Ivoire", "label": "Côte d'Ivoire"},
            {"code": "Croatia", "label": "Croatia"},
            {"code": "Cuba", "label": "Cuba"},
            {"code": "Cyprus", "label": "Cyprus"},
            {"code": "Czechia", "label": "Czechia"},
            {"code": "Denmark", "label": "Denmark"},
            {"code": "Djibouti", "label": "Djibouti"},
            {"code": "Dominica", "label": "Dominica"},
            {"code": "Dominican Republic", "label": "Dominican Republic"},
            {"code": "Ecuador", "label": "Ecuador"},
            {"code": "Egypt", "label": "Egypt"},
            {"code": "El Salvador", "label": "El Salvador"},
            {"code": "Equatorial Guinea", "label": "Equatorial Guinea"},
            {"code": "Eritrea", "label": "Eritrea"},
            {"code": "Estonia", "label": "Estonia"},
            {"code": "Eswatini", "label": "Eswatini"},
            {"code": "Ethiopia", "label": "Ethiopia"},
            {"code": "Fiji", "label": "Fiji"},
            {"code": "Finland", "label": "Finland"},
            {"code": "France", "label": "France"},
            {"code": "Gabon", "label": "Gabon"},
            {"code": "Gambia", "label": "Gambia"},
            {"code": "Georgia", "label": "Georgia"},
            {"code": "Germany", "label": "Germany"},
            {"code": "Ghana", "label": "Ghana"},
            {"code": "Greece", "label": "Greece"},
            {"code": "Grenada", "label": "Grenada"},
            {"code": "Guatemala", "label": "Guatemala"},
            {"code": "Guinea", "label": "Guinea"},
            {"code": "Guinea-Bissau", "label": "Guinea-Bissau"},
            {"code": "Guyana", "label": "Guyana"},
            {"code": "Haiti", "label": "Haiti"},
            {"code": "Honduras", "label": "Honduras"},
            {"code": "Hungary", "label": "Hungary"},
            {"code": "Iceland", "label": "Iceland"},
            {"code": "India", "label": "India"},
            {"code": "Indonesia", "label": "Indonesia"},
            {"code": "Iran", "label": "Iran"},
            {"code": "Iraq", "label": "Iraq"},
            {"code": "Ireland", "label": "Ireland"},
            {"code": "Israel", "label": "Israel"},
            {"code": "Italy", "label": "Italy"},
            {"code": "Jamaica", "label": "Jamaica"},
            {"code": "Japan", "label": "Japan"},
            {"code": "Jordan", "label": "Jordan"},
            {"code": "Kazakhstan", "label": "Kazakhstan"},
            {"code": "Kenya", "label": "Kenya"},
            {"code": "Kiribati", "label": "Kiribati"},
            {"code": "Kuwait", "label": "Kuwait"},
            {"code": "Kyrgyzstan", "label": "Kyrgyzstan"},
            {"code": "Laos", "label": "Laos"},
            {"code": "Latvia", "label": "Latvia"},
            {"code": "Lebanon", "label": "Lebanon"},
            {"code": "Lesotho", "label": "Lesotho"},
            {"code": "Liberia", "label": "Liberia"},
            {"code": "Libya", "label": "Libya"},
            {"code": "Liechtenstein", "label": "Liechtenstein"},
            {"code": "Lithuania", "label": "Lithuania"},
            {"code": "Luxembourg", "label": "Luxembourg"},
            {"code": "Madagascar", "label": "Madagascar"},
            {"code": "Malawi", "label": "Malawi"},
            {"code": "Malaysia", "label": "Malaysia"},
            {"code": "Maldives", "label": "Maldives"},
            {"code": "Mali", "label": "Mali"},
            {"code": "Malta", "label": "Malta"},
            {"code": "Marshall Islands", "label": "Marshall Islands"},
            {"code": "Mauritania", "label": "Mauritania"},
            {"code": "Mauritius", "label": "Mauritius"},
            {"code": "Mexico", "label": "Mexico"},
            {"code": "Micronesia", "label": "Micronesia"},
            {"code": "Moldova", "label": "Moldova"},
            {"code": "Monaco", "label": "Monaco"},
            {"code": "Mongolia", "label": "Mongolia"},
            {"code": "Montenegro", "label": "Montenegro"},
            {"code": "Morocco", "label": "Morocco"},
            {"code": "Mozambique", "label": "Mozambique"},
            {"code": "Myanmar", "label": "Myanmar"},
            {"code": "Namibia", "label": "Namibia"},
            {"code": "Nauru", "label": "Nauru"},
            {"code": "Nepal", "label": "Nepal"},
            {"code": "Netherlands", "label": "Netherlands"},
            {"code": "New Zealand", "label": "New Zealand"},
            {"code": "Nicaragua", "label": "Nicaragua"},
            {"code": "Niger", "label": "Niger"},
            {"code": "Nigeria", "label": "Nigeria"},
            {"code": "North Korea", "label": "North Korea"},
            {"code": "North Macedonia", "label": "North Macedonia"},
            {"code": "Norway", "label": "Norway"},
            {"code": "Oman", "label": "Oman"},
            {"code": "Pakistan", "label": "Pakistan"},
            {"code": "Palestine", "label": "Palestine"},
            {"code": "Palau", "label": "Palau"},
            {"code": "Panama", "label": "Panama"},
            {"code": "Papua New Guinea", "label": "Papua New Guinea"},
            {"code": "Paraguay", "label": "Paraguay"},
            {"code": "Peru", "label": "Peru"},
            {"code": "Philippines", "label": "Philippines"},
            {"code": "Poland", "label": "Poland"},
            {"code": "Portugal", "label": "Portugal"},
            {"code": "Qatar", "label": "Qatar"},
            {"code": "Romania", "label": "Romania"},
            {"code": "Russia", "label": "Russia"},
            {"code": "Rwanda", "label": "Rwanda"},
            {"code": "Saint Kitts and Nevis", "label": "Saint Kitts and Nevis"},
            {"code": "Saint Lucia", "label": "Saint Lucia"},
            {"code": "Saint Vincent and the Grenadines", "label": "Saint Vincent and the Grenadines"},
            {"code": "Samoa", "label": "Samoa"},
            {"code": "San Marino", "label": "San Marino"},
            {"code": "Sao Tome and Principe", "label": "Sao Tome and Principe"},
            {"code": "Saudi Arabia", "label": "Saudi Arabia"},
            {"code": "Senegal", "label": "Senegal"},
            {"code": "Serbia", "label": "Serbia"},
            {"code": "Seychelles", "label": "Seychelles"},
            {"code": "Sierra Leone", "label": "Sierra Leone"},
            {"code": "Singapore", "label": "Singapore"},
            {"code": "Slovakia", "label": "Slovakia"},
            {"code": "Slovenia", "label": "Slovenia"},
            {"code": "Solomon Islands", "label": "Solomon Islands"},
            {"code": "Somalia", "label": "Somalia"},
            {"code": "South Africa", "label": "South Africa"},
            {"code": "South Korea", "label": "South Korea"},
            {"code": "South Sudan", "label": "South Sudan"},
            {"code": "Spain", "label": "Spain"},
            {"code": "Sri Lanka", "label": "Sri Lanka"},
            {"code": "Sudan", "label": "Sudan"},
            {"code": "Suriname", "label": "Suriname"},
            {"code": "Sweden", "label": "Sweden"},
            {"code": "Switzerland", "label": "Switzerland"},
            {"code": "Syria", "label": "Syria"},
            {"code": "Tajikistan", "label": "Tajikistan"},
            {"code": "Tanzania", "label": "Tanzania"},
            {"code": "Thailand", "label": "Thailand"},
            {"code": "Timor-Leste", "label": "Timor-Leste"},
            {"code": "Togo", "label": "Togo"},
            {"code": "Tonga", "label": "Tonga"},
            {"code": "Trinidad and Tobago", "label": "Trinidad and Tobago"},
            {"code": "Tunisia", "label": "Tunisia"},
            {"code": "Turkey", "label": "Turkey"},
            {"code": "Turkmenistan", "label": "Turkmenistan"},
            {"code": "Tuvalu", "label": "Tuvalu"},
            {"code": "Uganda", "label": "Uganda"},
            {"code": "Ukraine", "label": "Ukraine"},
            {"code": "United Arab Emirates", "label": "United Arab Emirates"},
            {"code": "United Kingdom", "label": "United Kingdom"},
            {"code": "United States", "label": "United States"},
            {"code": "Uruguay", "label": "Uruguay"},
            {"code": "Uzbekistan", "label": "Uzbekistan"},
            {"code": "Vanuatu", "label": "Vanuatu"},
            {"code": "Vatican City", "label": "Vatican City"},
            {"code": "Venezuela", "label": "Venezuela"},
            {"code": "Vietnam", "label": "Vietnam"},
            {"code": "Yemen", "label": "Yemen"},
            {"code": "Zambia", "label": "Zambia"},
            {"code": "Zimbabwe", "label": "Zimbabwe"},
            # Disputed/Partially recognized states as of 2021:
            {"code": "Kosovo", "label": "Kosovo"},
            {"code": "Transnistria", "label": "Transnistria"},
            {"code": "Abkhazia", "label": "Abkhazia"},
            {"code": "South Ossetia", "label": "South Ossetia"},
            # Easter Egg: Antarctica
            {"code": "Antarctica", "label": "Antarctica"}
        ]

        # Attributes for scrolling in More Countries sub-menu
        self.more_countries_scroll_offset = 0
        self.more_countries_dragging_scrollbar = False
        self.more_countries_scrollbar_drag_offset = 0
        self.more_countries_scrollbar_rect = None

        # Load flag images (both full and scaled versions)
        self.load_flag_images()

    def load_image(self, path, alpha=True, convert=True):
        if not os.path.exists(path):
            print(f"Warning: {path} not found, using placeholder.")
            image = pygame.Surface((100, 60))
            image.fill((200, 200, 200))
            return image.convert_alpha() if alpha else image.convert()
        try:
            image = pygame.image.load(path)
            if convert:
                return image.convert_alpha() if alpha else image.convert()
            return image
        except Exception as e:
            print(f"Error loading {path}: {e}")
            sys.exit()

    def load_resources(self):
        # Load icons and backgrounds
        self.game_icon = self.load_image(os.path.join("icons", "game_icon.png"))
        self.imperial_img = self.load_image(os.path.join("icons", "imperial_horizons.png"))
        try:
            self.button_img = self.load_image(os.path.join("icons", "button.png"))
        except Exception as e:
            print("Error loading button image, proceeding without it.")
            self.button_img = None

        self.main_menu_bg = self.load_image(os.path.join("icons", "main_menu_background.png"), alpha=False) if os.path.exists(os.path.join("icons", "main_menu_background.png")) else None
        self.settings_bg = self.load_image(os.path.join("icons", "settings_background.png"), alpha=False) if os.path.exists(os.path.join("icons", "settings_background.png")) else None
        self.loadgame_bg = self.load_image(os.path.join("icons", "loadgame_background.png"), alpha=False) if os.path.exists(os.path.join("icons", "loadgame_background.png")) else None
        self.newgame_bg = self.load_image(os.path.join("icons", "newgame_background.png"), alpha=False) if os.path.exists(os.path.join("icons", "newgame_background.png")) else None

    def get_flag_filename(self, country):
        # Convert full country name to lowercase and replace spaces with underscores.
        base = country["code"].lower().replace(" ", "_")
        return f"{base}_flag_flag.png"

    def load_flag_images(self):
        # Cache the original flag images and pre-scaled versions for different sub-menus.
        self.flag_images = {}
        self.flag_images_newgame = {}
        self.flag_images_more = {}
        for country in self.all_countries:
            filename = self.get_flag_filename(country)
            path = os.path.join("flags", filename)
            image = self.load_image(path)
            self.flag_images[country["code"]] = image
            # For new game: 100x60, for more countries: 50x30.
            self.flag_images_newgame[country["code"]] = pygame.transform.scale(image, (100, 60))
            self.flag_images_more[country["code"]] = pygame.transform.scale(image, (50, 30))

    def toggle_fullscreen(self):
        self.is_fullscreen = not self.is_fullscreen
        if self.is_fullscreen:
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            info = pygame.display.Info()
            self.SCREEN_WIDTH, self.SCREEN_HEIGHT = info.current_w, info.current_h
        else:
            self.SCREEN_WIDTH, self.SCREEN_HEIGHT = 1280, 720
            self.screen = pygame.display.set_mode((self.SCREEN_WIDTH, self.SCREEN_HEIGHT))

    def save_game(self):
        filename = os.path.join("save", f"save_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
        with open(filename, "w") as f:
            f.write(f"sim_time: {self.sim_time}\n")
            f.write(f"camera: {self.camera_x}, {self.camera_y}\n")
            f.write(f"zoom: {self.zoom}\n")
        print("Game saved to", filename)

    def load_game(self, filename):
        print("Loaded game from", filename)
        # Insert load logic here

    def draw_button(self, rect, text):
        if self.button_img:
            scaled_btn = pygame.transform.scale(self.button_img, (rect.width, rect.height))
            self.screen.blit(scaled_btn, rect.topleft)
        else:
            pygame.draw.rect(self.screen, (100, 100, 100), rect)
        text_surf = self.button_font.render(text, True, (0, 0, 0))
        self.screen.blit(text_surf, text_surf.get_rect(center=rect.center))

    def run(self):
        running = True
        while running:
            dt = self.clock.tick(self.fps_setting) / 1000.0
            self.handle_events(dt)
            self.update(dt)
            self.draw()
            pygame.display.flip()
        pygame.quit()

    def handle_events(self, dt):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if self.current_state == "in_game":
                self.handle_in_game_event(event)
            elif self.current_state == "main_menu":
                self.handle_main_menu_event(event)
            elif self.current_state == "settings":
                self.handle_settings_event(event)
            elif self.current_state == "load_game":
                self.handle_load_game_event(event)
            elif self.current_state == "new_game":
                self.handle_new_game_event(event)
            elif self.current_state == "more_countries":
                self.handle_more_countries_event(event)
            elif self.current_state == "scenarios":
                self.handle_scenarios_event(event)
            if self.button_cooldown > 0:
                self.button_cooldown -= dt

    def handle_in_game_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            fs_button_rect = pygame.Rect(self.SCREEN_WIDTH - 45, 5, 30, 30)
            if event.button == 1 and fs_button_rect.collidepoint(event.pos):
                self.toggle_fullscreen()
                return
            if event.button == 3 and not self.in_ui_area(event.pos):
                self.selecting = True
                self.selection_start = event.pos
                self.selection_rect = pygame.Rect(event.pos, (0, 0))
        if event.type == pygame.MOUSEBUTTONUP:
            if event.button == 3:
                self.selecting = False
                self.selection_start = None
                self.selection_rect = None
        if event.type == pygame.MOUSEMOTION and self.selecting and self.selection_start:
            x1, y1 = self.selection_start
            x2, y2 = event.pos
            self.selection_rect = pygame.Rect(min(x1, x2), min(y1, y2), abs(x2 - x1), abs(y2 - y1))
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_F5:
                self.save_game()
            elif event.key == pygame.K_ESCAPE:
                self.current_state = "main_menu"
            elif event.key == pygame.K_SPACE:
                self.paused = not self.paused
            elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS) and self.time_multiplier_state > 1:
                self.time_multiplier_state -= 1
            elif event.key in (pygame.K_EQUALS, pygame.K_KP_PLUS) and self.time_multiplier_state < 5:
                self.time_multiplier_state += 1
            elif event.key == pygame.K_e:
                self.zoom += self.ZOOM_SPEED
                if self.zoom < self.MIN_ZOOM:
                    self.zoom = self.MIN_ZOOM
            elif event.key == pygame.K_q:
                self.zoom -= self.ZOOM_SPEED
                if self.zoom < self.MIN_ZOOM:
                    self.zoom = self.MIN_ZOOM
        if event.type == pygame.MOUSEWHEEL:
            self.zoom += event.y * self.ZOOM_SPEED
            if self.zoom < self.MIN_ZOOM:
                self.zoom = self.MIN_ZOOM

    def in_ui_area(self, pos):
        top_bar_rect = pygame.Rect(0, 0, self.SCREEN_WIDTH, self.top_bar_height)
        clock_bar_rect = pygame.Rect(self.SCREEN_WIDTH - 210, self.top_bar_height + 10, 200, 40)
        ui_bar_rect = pygame.Rect(self.SCREEN_WIDTH - 210, self.top_bar_height + 60, 200, 40)
        return top_bar_rect.collidepoint(pos) or clock_bar_rect.collidepoint(pos) or ui_bar_rect.collidepoint(pos)

    def handle_main_menu_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.button_cooldown <= 0:
            mouse_pos = event.pos
            button_width = 200
            button_height = 50
            spacing = 60
            start_y = self.SCREEN_HEIGHT // 2
            new_game_btn = pygame.Rect((self.SCREEN_WIDTH - button_width) // 2, start_y, button_width, button_height)
            load_game_btn = pygame.Rect((self.SCREEN_WIDTH - button_width) // 2, start_y + spacing, button_width, button_height)
            settings_btn = pygame.Rect((self.SCREEN_WIDTH - button_width) // 2, start_y + 2 * spacing, button_width, button_height)
            quit_btn = pygame.Rect((self.SCREEN_WIDTH - button_width) // 2, start_y + 3 * spacing, button_width, button_height)
            if new_game_btn.collidepoint(mouse_pos):
                self.current_state = "new_game"
                self.button_cooldown = 0.3
            elif load_game_btn.collidepoint(mouse_pos):
                self.current_state = "load_game"
                self.button_cooldown = 0.3
            elif settings_btn.collidepoint(mouse_pos):
                self.temp_fps = self.fps_setting
                self.temp_sound = self.sound_setting
                self.temp_music = self.music_setting
                self.temp_fullscreen = self.is_fullscreen
                self.current_state = "settings"
                self.button_cooldown = 0.3
            elif quit_btn.collidepoint(mouse_pos):
                pygame.quit()
                sys.exit()

    def handle_settings_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.button_cooldown <= 0:
            mouse_pos = event.pos
            option_start_y = self.SCREEN_HEIGHT // 2 - 150
            option_spacing = 70
            minus_x = self.SCREEN_WIDTH // 2 - 100
            small_btn_size = 30
            plus_x = self.SCREEN_WIDTH // 2 + 40

            fps_minus = pygame.Rect(minus_x, option_start_y, small_btn_size, small_btn_size)
            fps_plus = pygame.Rect(plus_x, option_start_y, small_btn_size, small_btn_size)
            sound_minus = pygame.Rect(minus_x, option_start_y + option_spacing, small_btn_size, small_btn_size)
            sound_plus = pygame.Rect(plus_x, option_start_y + option_spacing, small_btn_size, small_btn_size)
            music_minus = pygame.Rect(minus_x, option_start_y + 2 * option_spacing, small_btn_size, small_btn_size)
            music_plus = pygame.Rect(plus_x, option_start_y + 2 * option_spacing, small_btn_size, small_btn_size)
            fs_toggle = pygame.Rect(minus_x, option_start_y + 3 * option_spacing, 60, small_btn_size)

            apply_btn = pygame.Rect(0, 0, 100, 40)
            apply_btn.center = (self.SCREEN_WIDTH // 2 - 60, self.SCREEN_HEIGHT - 80)
            back_btn = pygame.Rect(0, 0, 100, 40)
            back_btn.center = (self.SCREEN_WIDTH // 2 + 60, self.SCREEN_HEIGHT - 80)
            if fps_minus.collidepoint(mouse_pos) and self.temp_fps > 30:
                self.temp_fps -= 5
                self.button_cooldown = 0.15
            elif fps_plus.collidepoint(mouse_pos) and self.temp_fps < 120:
                self.temp_fps += 5
                self.button_cooldown = 0.15
            elif sound_minus.collidepoint(mouse_pos) and self.temp_sound > 0:
                self.temp_sound -= 5
                self.button_cooldown = 0.15
            elif sound_plus.collidepoint(mouse_pos) and self.temp_sound < 100:
                self.temp_sound += 5
                self.button_cooldown = 0.15
            elif music_minus.collidepoint(mouse_pos) and self.temp_music > 0:
                self.temp_music -= 5
                self.button_cooldown = 0.15
            elif music_plus.collidepoint(mouse_pos) and self.temp_music < 100:
                self.temp_music += 5
                self.button_cooldown = 0.15
            elif fs_toggle.collidepoint(mouse_pos):
                self.temp_fullscreen = not self.temp_fullscreen
                self.button_cooldown = 0.15
            elif apply_btn.collidepoint(mouse_pos):
                if self.temp_fullscreen != self.is_fullscreen:
                    self.toggle_fullscreen()
                self.fps_setting = self.temp_fps
                self.sound_setting = self.temp_sound
                self.music_setting = self.temp_music
                print(f"Settings applied: FPS={self.fps_setting}, Sound={self.temp_sound}, Music={self.temp_music}")
                self.current_state = "main_menu"
                self.button_cooldown = 0.2
            elif back_btn.collidepoint(mouse_pos):
                self.current_state = "main_menu"
                self.button_cooldown = 0.2

    def handle_load_game_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.button_cooldown <= 0:
            mouse_pos = event.pos
            save_files = os.listdir("save")
            y_offset = 100
            file_clicked = False
            for file in save_files:
                file_rect = pygame.Rect(100, y_offset, self.SCREEN_WIDTH - 200, 30)
                if file_rect.collidepoint(mouse_pos):
                    self.load_game(file)
                    self.current_state = "in_game"
                    self.button_cooldown = 0.3
                    file_clicked = True
                    break
                y_offset += 40
            back_btn = pygame.Rect((self.SCREEN_WIDTH - 80) // 2, self.SCREEN_HEIGHT - 60, 80, 40)
            if not file_clicked and back_btn.collidepoint(mouse_pos):
                self.current_state = "main_menu"
                self.button_cooldown = 0.3

    def handle_new_game_event(self, event):
        gray_bar_width = int(self.SCREEN_WIDTH * 0.9)
        gray_bar_height = 500
        gray_bar_x = (self.SCREEN_WIDTH - gray_bar_width) // 2
        gray_bar_y = (self.SCREEN_HEIGHT - gray_bar_height) // 2
        # Draw a black bar at the top of the gray box (this is drawn in draw_new_game, but we reuse its coordinates here)
        black_bar_height = 30

        flag_area_y = gray_bar_y + black_bar_height + 20
        flag_width, flag_height = 100, 60
        num_flags = 5
        gap = (gray_bar_width - (num_flags * flag_width)) / (num_flags + 1)
        countries = [
            {"code": "United States", "label": "United States"},
            {"code": "China", "label": "China"},
            {"code": "Russia", "label": "Russia"},
            {"code": "India", "label": "India"},
            {"code": "United Kingdom", "label": "United Kingdom"}
        ]
        if event.type == pygame.MOUSEMOTION:
            hovered = None
            for i in range(num_flags):
                x = gray_bar_x + gap + i * (flag_width + gap)
                flag_rect = pygame.Rect(x, flag_area_y, flag_width, flag_height)
                if flag_rect.collidepoint(event.pos):
                    hovered = countries[i]["code"]
                    break
            self.hovered_country = hovered
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.button_cooldown <= 0:
            mouse_pos = event.pos
            for i in range(num_flags):
                x = gray_bar_x + gap + i * (flag_width + gap)
                flag_rect = pygame.Rect(x, flag_area_y, flag_width, flag_height)
                if flag_rect.collidepoint(mouse_pos):
                    if self.selected_country == countries[i]["code"]:
                        self.selected_country = None
                    else:
                        self.selected_country = countries[i]["code"]
                    self.button_cooldown = 0.3
                    break

            # Calculate info box and buttons positions.
            info_box_width = int(gray_bar_width * 0.4)
            info_box_height = 200
            info_box_x = gray_bar_x + 20
            info_box_y = gray_bar_y + gray_bar_height - info_box_height - 20
            info_box_rect = pygame.Rect(info_box_x, info_box_y, info_box_width, info_box_height)
            more_btn_width = 150
            more_btn_height = 40
            more_btn_x = info_box_rect.right + 10
            more_btn_y = info_box_rect.centery - more_btn_height // 2
            more_btn_rect = pygame.Rect(more_btn_x, more_btn_y, more_btn_width, more_btn_height)
            if more_btn_rect.collidepoint(mouse_pos):
                self.current_state = "more_countries"
                self.button_cooldown = 0.3
                return

            # Check Scenario's button positioned just below the More Countries button.
            scenario_btn_rect = pygame.Rect(more_btn_x, more_btn_rect.bottom + 10, more_btn_width, more_btn_height)
            if scenario_btn_rect.collidepoint(mouse_pos):
                self.current_state = "scenarios"
                self.button_cooldown = 0.3
                return

            button_y = self.SCREEN_HEIGHT - 50
            # Reposition buttons farther apart to avoid overlap.
            start_btn = pygame.Rect(0, 0, 150, 40)
            start_btn.center = (self.SCREEN_WIDTH // 2 - 100, button_y)
            back_btn = pygame.Rect(0, 0, 150, 40)
            back_btn.center = (self.SCREEN_WIDTH // 2 + 100, button_y)
            if start_btn.collidepoint(mouse_pos):
                self.paused = False
                self.spectator_mode = (self.selected_country is None)
                self.current_state = "in_game"
                self.button_cooldown = 0.3
            elif back_btn.collidepoint(mouse_pos):
                self.current_state = "main_menu"
                self.button_cooldown = 0.3

    def handle_more_countries_event(self, event):
        # Define a larger container for the More Countries menu.
        container_width = int(self.SCREEN_WIDTH * 0.95)
        container_height = int(self.SCREEN_HEIGHT * 0.9)
        container_x = (self.SCREEN_WIDTH - container_width) // 2
        container_y = (self.SCREEN_HEIGHT - container_height) // 2

        # Reserve bottom area for a Back button.
        button_area_height = 80
        search_bar_height = 40
        # Place search bar above the button area.
        search_bar_y = container_y + container_height - button_area_height - search_bar_height - 20
        list_area_y = container_y + 60
        list_area_bottom = search_bar_y - 10  # margin
        row_height = 50
        gap = 10
        filtered_countries = [c for c in self.all_countries if self.search_text.lower() in c["label"].lower()]
        total_list_height = max(0, len(filtered_countries) * (row_height + gap) - gap)
        visible_height = list_area_bottom - list_area_y

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # Check if click on scrollbar slider
            if self.more_countries_scrollbar_rect and self.more_countries_scrollbar_rect.collidepoint(event.pos):
                self.more_countries_dragging_scrollbar = True
                self.more_countries_scrollbar_drag_offset = event.pos[1] - self.more_countries_scrollbar_rect.top
                return
            # Check for clicks on country rows
            for i, country in enumerate(filtered_countries):
                row_y = list_area_y + i * (row_height + gap) - self.more_countries_scroll_offset
                if row_y < list_area_y:
                    continue
                if row_y + row_height > list_area_bottom:
                    break
                row_rect = pygame.Rect(container_x + 20, row_y, container_width - 60, row_height)
                if row_rect.collidepoint(event.pos):
                    if self.selected_country == country["code"]:
                        self.selected_country = None
                    else:
                        self.selected_country = country["code"]
                    return
            # Check for clicks on the Back button only.
            back_btn = pygame.Rect(0, 0, 150, 40)
            back_btn.center = (container_x + container_width/2, container_y + container_height - button_area_height/2)
            if back_btn.collidepoint(event.pos):
                self.current_state = "new_game"
                self.button_cooldown = 0.3
                return

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.more_countries_dragging_scrollbar = False

        elif event.type == pygame.MOUSEMOTION:
            if self.more_countries_dragging_scrollbar:
                track_top = list_area_y
                track_height = visible_height
                slider_height = self.more_countries_scrollbar_rect.height if self.more_countries_scrollbar_rect else 20
                new_slider_top = event.pos[1] - self.more_countries_scrollbar_drag_offset
                new_slider_top = max(track_top, min(new_slider_top, track_top + track_height - slider_height))
                if total_list_height > visible_height:
                    self.more_countries_scroll_offset = ((new_slider_top - track_top) / (track_height - slider_height)) * (total_list_height - visible_height)
            else:
                pass

        elif event.type == pygame.MOUSEWHEEL:
            self.more_countries_scroll_offset -= event.y * 20

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.current_state = "new_game"
                self.button_cooldown = 0.3
            elif event.key == pygame.K_BACKSPACE:
                self.search_text = self.search_text[:-1]
            elif event.key == pygame.K_RETURN:
                pass
            else:
                self.search_text += event.unicode

        max_scroll = max(total_list_height - visible_height, 0)
        self.more_countries_scroll_offset = max(0, min(self.more_countries_scroll_offset, max_scroll))

    def handle_scenarios_event(self, event):
        # Basic Scenario Sub-Menu Event Handler.
        container_width = int(self.SCREEN_WIDTH * 0.8)
        container_height = int(self.SCREEN_HEIGHT * 0.8)
        container_x = (self.SCREEN_WIDTH - container_width) // 2
        container_y = (self.SCREEN_HEIGHT - container_height) // 2
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.button_cooldown <= 0:
            back_btn = pygame.Rect(0, 0, 150, 40)
            back_btn.center = (container_x + container_width // 2, container_y + container_height - 50)
            if back_btn.collidepoint(event.pos):
                self.current_state = "new_game"
                self.button_cooldown = 0.3

    def draw_main_menu(self):
        if self.main_menu_bg:
            scaled_bg = pygame.transform.scale(self.main_menu_bg, (self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
            self.screen.blit(scaled_bg, (0, 0))
        else:
            self.screen.fill((0, 0, 0))
        if self.game_icon:
            icon_rect = self.game_icon.get_rect(midtop=(self.SCREEN_WIDTH // 2, 50))
            self.screen.blit(self.game_icon, icon_rect)
        if self.imperial_img:
            imperial_top = icon_rect.bottom + 20 if self.game_icon else 150
            imperial_rect = self.imperial_img.get_rect(midtop=(self.SCREEN_WIDTH // 2, imperial_top))
            self.screen.blit(self.imperial_img, imperial_rect)
        button_width = 200
        button_height = 50
        spacing = 60
        start_y = self.SCREEN_HEIGHT // 2
        new_game_btn = pygame.Rect((self.SCREEN_WIDTH - button_width) // 2, start_y, button_width, button_height)
        load_game_btn = pygame.Rect((self.SCREEN_WIDTH - button_width) // 2, start_y + spacing, button_width, button_height)
        settings_btn = pygame.Rect((self.SCREEN_WIDTH - button_width) // 2, start_y + 2 * spacing, button_width, button_height)
        quit_btn = pygame.Rect((self.SCREEN_WIDTH - button_width) // 2, start_y + 3 * spacing, button_width, button_height)
        self.draw_button(new_game_btn, "New Game")
        self.draw_button(load_game_btn, "Load Game")
        self.draw_button(settings_btn, "Settings")
        self.draw_button(quit_btn, "Quit")

    def draw_settings(self):
        if self.settings_bg:
            scaled_bg = pygame.transform.scale(self.settings_bg, (self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
            self.screen.blit(scaled_bg, (0, 0))
        else:
            self.screen.fill((0, 0, 0))
        title_text = self.menu_font.render("Settings", True, (0, 0, 0))
        title_rect = title_text.get_rect(center=(self.SCREEN_WIDTH // 2, self.SCREEN_HEIGHT // 6))
        self.screen.blit(title_text, title_rect)

        option_start_y = self.SCREEN_HEIGHT // 2 - 150
        option_spacing = 70
        label_x = self.SCREEN_WIDTH // 4
        minus_x = self.SCREEN_WIDTH // 2 - 100
        small_btn_size = 30
        plus_x = self.SCREEN_WIDTH // 2 + 40

        fps_label = self.font.render("FPS:", True, (0, 0, 0))
        self.screen.blit(fps_label, (label_x, option_start_y))
        fps_minus = pygame.Rect(minus_x, option_start_y, small_btn_size, small_btn_size)
        self.draw_small_button(fps_minus, "-")
        fps_value = self.button_font.render(str(self.temp_fps), True, (0, 0, 0))
        value_x = (minus_x + small_btn_size + plus_x) // 2
        self.screen.blit(fps_value, fps_value.get_rect(center=(value_x, option_start_y + 15)))
        fps_plus = pygame.Rect(plus_x, option_start_y, small_btn_size, small_btn_size)
        self.draw_small_button(fps_plus, "+")

        sound_y = option_start_y + option_spacing
        sound_label = self.font.render("Sound:", True, (0, 0, 0))
        self.screen.blit(sound_label, (label_x, sound_y))
        sound_minus = pygame.Rect(minus_x, sound_y, small_btn_size, small_btn_size)
        self.draw_small_button(sound_minus, "-")
        sound_value = self.button_font.render(str(self.temp_sound), True, (0, 0, 0))
        self.screen.blit(sound_value, sound_value.get_rect(center=(value_x, sound_y + 15)))
        sound_plus = pygame.Rect(plus_x, sound_y, small_btn_size, small_btn_size)
        self.draw_small_button(sound_plus, "+")

        music_y = option_start_y + 2 * option_spacing
        music_label = self.font.render("Music:", True, (0, 0, 0))
        self.screen.blit(music_label, (label_x, music_y))
        music_minus = pygame.Rect(minus_x, music_y, small_btn_size, small_btn_size)
        self.draw_small_button(music_minus, "-")
        music_value = self.button_font.render(str(self.temp_music), True, (0, 0, 0))
        self.screen.blit(music_value, music_value.get_rect(center=(value_x, music_y + 15)))
        music_plus = pygame.Rect(plus_x, music_y, small_btn_size, small_btn_size)
        self.draw_small_button(music_plus, "+")

        fs_y = option_start_y + 3 * option_spacing
        fs_label = self.font.render("Full Screen:", True, (0, 0, 0))
        self.screen.blit(fs_label, (label_x, fs_y))
        fs_toggle = pygame.Rect(minus_x, fs_y, 60, small_btn_size)
        pygame.draw.rect(self.screen, (200, 200, 200), fs_toggle)
        pygame.draw.rect(self.screen, (0, 0, 0), fs_toggle, 2)
        toggle_text = "On" if self.temp_fullscreen else "Off"
        toggle_surf = self.button_font.render(toggle_text, True, (0, 0, 0))
        self.screen.blit(toggle_surf, toggle_surf.get_rect(center=fs_toggle.center))

        apply_btn = pygame.Rect(0, 0, 100, 40)
        apply_btn.center = (self.SCREEN_WIDTH // 2 - 60, self.SCREEN_HEIGHT - 80)
        back_btn = pygame.Rect(0, 0, 100, 40)
        back_btn.center = (self.SCREEN_WIDTH // 2 + 60, self.SCREEN_HEIGHT - 80)
        self.draw_small_button(apply_btn, "Apply")
        self.draw_small_button(back_btn, "Back")

    def draw_small_button(self, rect, text):
        if self.button_img:
            scaled = pygame.transform.scale(self.button_img, (rect.width, rect.height))
            self.screen.blit(scaled, rect.topleft)
        else:
            pygame.draw.rect(self.screen, (100, 100, 100), rect)
        t_surf = self.button_font.render(text, True, (0, 0, 0))
        self.screen.blit(t_surf, t_surf.get_rect(center=rect.center))

    def draw_load_game(self):
        if self.loadgame_bg:
            scaled_bg = pygame.transform.scale(self.loadgame_bg, (self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
            self.screen.blit(scaled_bg, (0, 0))
        else:
            self.screen.fill((0, 0, 0))
        title_text = self.font.render("Load Game", True, (0, 0, 0))
        self.screen.blit(title_text, (self.SCREEN_WIDTH // 2 - title_text.get_width() // 2, 30))
        y_offset = 100
        save_files = os.listdir("save")
        for file in save_files:
            file_rect = pygame.Rect(100, y_offset, self.SCREEN_WIDTH - 200, 30)
            if self.button_img:
                scaled_btn = pygame.transform.scale(self.button_img, (file_rect.width, file_rect.height))
                self.screen.blit(scaled_btn, file_rect.topleft)
            else:
                pygame.draw.rect(self.screen, (100, 100, 100), file_rect)
            file_text = self.button_font.render(file, True, (0, 0, 0))
            self.screen.blit(file_text, file_text.get_rect(center=file_rect.center))
            y_offset += 40
        back_btn = pygame.Rect((self.SCREEN_WIDTH - 80) // 2, self.SCREEN_HEIGHT - 60, 80, 40)
        if self.button_img:
            scaled_back = pygame.transform.scale(self.button_img, (back_btn.width, back_btn.height))
            self.screen.blit(scaled_back, back_btn.topleft)
        else:
            pygame.draw.rect(self.screen, (100, 100, 100), back_btn)
        back_text = self.button_font.render("Back", True, (0, 0, 0))
        self.screen.blit(back_text, back_text.get_rect(center=back_btn.center))

    def draw_new_game(self):
        if self.newgame_bg:
            scaled_bg = pygame.transform.scale(self.newgame_bg, (self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
            self.screen.blit(scaled_bg, (0, 0))
        else:
            self.screen.fill((0, 0, 0))
        gray_bar_width = int(self.SCREEN_WIDTH * 0.9)
        gray_bar_height = 500
        gray_bar_x = (self.SCREEN_WIDTH - gray_bar_width) // 2
        gray_bar_y = (self.SCREEN_HEIGHT - gray_bar_height) // 2
        gray_bar_rect = pygame.Rect(gray_bar_x, gray_bar_y, gray_bar_width, gray_bar_height)
        pygame.draw.rect(self.screen, (160, 160, 160), gray_bar_rect)
        black_bar_height = 30
        black_bar_rect = pygame.Rect(gray_bar_x, gray_bar_y, gray_bar_width, black_bar_height)
        pygame.draw.rect(self.screen, (0, 0, 0), black_bar_rect)
        choose_text = self.menu_font.render("Choose a Country", True, (0, 0, 0))
        self.screen.blit(choose_text, choose_text.get_rect(center=black_bar_rect.center))
        flag_area_y = black_bar_rect.bottom + 20
        flag_width, flag_height = 100, 60
        num_flags = 5
        gap = (gray_bar_width - (num_flags * flag_width)) / (num_flags + 1)
        countries = [
            {"code": "United States", "label": "United States"},
            {"code": "China", "label": "China"},
            {"code": "Russia", "label": "Russia"},
            {"code": "India", "label": "India"},
            {"code": "United Kingdom", "label": "United Kingdom"}
        ]
        # Draw default row of flags.
        for i in range(num_flags):
            x = gray_bar_x + gap + i * (flag_width + gap)
            flag_rect = pygame.Rect(x, flag_area_y, flag_width, flag_height)
            flag_img = self.flag_images_newgame.get(countries[i]["code"])
            if flag_img:
                self.screen.blit(flag_img, flag_rect.topleft)
            else:
                pygame.draw.rect(self.screen, (0, 0, 0), flag_rect)
            if (self.hovered_country == countries[i]["code"]) or (self.selected_country == countries[i]["code"]):
                overlay = pygame.Surface((flag_width, flag_height), pygame.SRCALPHA)
                overlay.fill((0, 255, 0, 100))
                self.screen.blit(overlay, flag_rect.topleft)
            label_text = self.button_font.render(countries[i]["label"], True, (0, 0, 0))
            self.screen.blit(label_text, label_text.get_rect(center=(flag_rect.centerx, flag_rect.bottom + 15)))
        
        # If a country from More Countries has been chosen (i.e. not one of the defaults), add its flag below the Russian flag.
        default_codes = {"United States", "China", "Russia", "India", "United Kingdom"}
        if self.selected_country and self.selected_country not in default_codes:
            # Align extra flag under the third flag (Russia); move it a little further down.
            extra_flag_x = gray_bar_x + gap + 2*(flag_width + gap)
            extra_flag_y = flag_area_y + flag_height + 40  # increased offset for clarity
            extra_flag_rect = pygame.Rect(extra_flag_x, extra_flag_y, flag_width, flag_height)
            extra_flag_img = self.flag_images_newgame.get(self.selected_country)
            if extra_flag_img:
                self.screen.blit(extra_flag_img, extra_flag_rect.topleft)
            else:
                pygame.draw.rect(self.screen, (0, 0, 0), extra_flag_rect)
        
        # Draw info box with country info.
        info_box_width = int(gray_bar_width * 0.4)
        info_box_height = 200
        info_box_x = gray_bar_x + 20
        info_box_y = gray_bar_y + gray_bar_height - info_box_height - 20
        info_box_rect = pygame.Rect(info_box_x, info_box_y, info_box_width, info_box_height)
        pygame.draw.rect(self.screen, (100, 100, 100), info_box_rect)
        pygame.draw.rect(self.screen, (0, 0, 0), info_box_rect, 2)
        if self.selected_country:
            if self.selected_country in self.country_info:
                info_text = self.country_info[self.selected_country]
            else:
                info_text = f"Country selected: {self.selected_country}"
        else:
            info_text = "No country selected."
        lines = info_text.split("\n")
        line_y = info_box_y + 5
        for line in lines:
            line_surf = self.info_font.render(line, True, (0, 0, 0))
            self.screen.blit(line_surf, (info_box_x + 5, line_y))
            line_y += line_surf.get_height() + 2

        # Draw More Countries Button next to the info box.
        more_btn_width = 150
        more_btn_height = 40
        more_btn_x = info_box_rect.right + 10
        more_btn_y = info_box_rect.centery - more_btn_height // 2
        more_btn_rect = pygame.Rect(more_btn_x, more_btn_y, more_btn_width, more_btn_height)
        self.draw_button(more_btn_rect, "More Countries")
        
        # Draw Scenario's Button below the More Countries Button.
        scenario_btn_rect = pygame.Rect(more_btn_x, more_btn_rect.bottom + 10, more_btn_width, more_btn_height)
        self.draw_button(scenario_btn_rect, "Scenario's")
        
        button_y = self.SCREEN_HEIGHT - 50
        # Reposition bottom buttons farther apart to fix mis-click issues.
        start_btn = pygame.Rect(0, 0, 150, 40)
        start_btn.center = (self.SCREEN_WIDTH // 2 - 100, button_y)
        back_btn = pygame.Rect(0, 0, 150, 40)
        back_btn.center = (self.SCREEN_WIDTH // 2 + 100, button_y)
        self.draw_button(start_btn, "Start Game")
        self.draw_button(back_btn, "Back")

    def draw_more_countries(self):
        container_width = int(self.SCREEN_WIDTH * 0.95)
        container_height = int(self.SCREEN_HEIGHT * 0.9)
        container_x = (self.SCREEN_WIDTH - container_width) // 2
        container_y = (self.SCREEN_HEIGHT - container_height) // 2
        pygame.draw.rect(self.screen, (160, 160, 160), (container_x, container_y, container_width, container_height))
        title_text = self.menu_font.render("More Countries", True, (0, 0, 0))
        self.screen.blit(title_text, title_text.get_rect(center=(container_x + container_width//2, container_y + 30)))
        
        button_area_height = 80
        search_bar_height = 40
        search_bar_y = container_y + container_height - button_area_height - search_bar_height - 20
        search_bar_rect = pygame.Rect(container_x + 20, search_bar_y, container_width - 40, search_bar_height)
        pygame.draw.rect(self.screen, (255, 255, 255), search_bar_rect)
        pygame.draw.rect(self.screen, (0, 0, 0), search_bar_rect, 2)
        # Use placeholder text when search_text is empty.
        if self.search_text == "":
            placeholder = "Search Bar, Search Countries here"
            search_text_surf = self.button_font.render(placeholder, True, (200, 200, 200))
        else:
            search_text_surf = self.button_font.render(self.search_text, True, (0, 0, 0))
        self.screen.blit(search_text_surf, (search_bar_rect.x + 5, search_bar_rect.y + (search_bar_height - search_text_surf.get_height()) // 2))
        
        list_area_y = container_y + 60
        list_area_bottom = search_bar_y - 10
        row_height = 50
        gap = 10
        filtered_countries = [c for c in self.all_countries if self.search_text.lower() in c["label"].lower()]
        total_list_height = max(0, len(filtered_countries) * (row_height + gap) - gap)
        visible_height = list_area_bottom - list_area_y

        for i, country in enumerate(filtered_countries):
            row_y = list_area_y + i * (row_height + gap) - self.more_countries_scroll_offset
            if row_y < list_area_y:
                continue
            if row_y + row_height > list_area_bottom:
                break
            row_rect = pygame.Rect(container_x + 20, row_y, container_width - 60, row_height)
            pygame.draw.rect(self.screen, (200, 200, 200), row_rect)
            flag_img = self.flag_images_more.get(country["code"])
            flag_width, flag_height = 50, 30
            if flag_img:
                self.screen.blit(flag_img, (row_rect.x + 5, row_rect.y + (row_height - flag_height) // 2))
            else:
                pygame.draw.rect(self.screen, (0, 0, 0), (row_rect.x + 5, row_rect.y + (row_height - flag_height) // 2, flag_width, flag_height))
            label_surf = self.button_font.render(country["label"], True, (0, 0, 0))
            self.screen.blit(label_surf, (row_rect.x + 5 + flag_width + 10, row_rect.y + (row_height - label_surf.get_height()) // 2))
            if self.selected_country == country["code"]:
                overlay = pygame.Surface((flag_width, flag_height), pygame.SRCALPHA)
                overlay.fill((0, 255, 0, 150))
                self.screen.blit(overlay, (row_rect.x + 5, row_rect.y + (row_height - flag_height) // 2))
        
        scrollbar_width = 20
        track_rect = pygame.Rect(container_x + container_width - 20, list_area_y, scrollbar_width, visible_height)
        pygame.draw.rect(self.screen, (100, 100, 100), track_rect)
        if total_list_height > visible_height:
            slider_height = max((visible_height / total_list_height) * visible_height, 20)
            max_scroll = total_list_height - visible_height
            slider_y = list_area_y + (self.more_countries_scroll_offset / max_scroll) * (visible_height - slider_height) if max_scroll > 0 else list_area_y
        else:
            slider_height = visible_height
            slider_y = list_area_y
        slider_rect = pygame.Rect(track_rect.x, slider_y, scrollbar_width, slider_height)
        pygame.draw.rect(self.screen, (200, 200, 200), slider_rect)
        self.more_countries_scrollbar_rect = slider_rect

        # Draw only a Back button here.
        back_btn = pygame.Rect(0, 0, 150, 40)
        back_btn.center = (container_x + container_width/2, container_y + container_height - button_area_height/2)
        self.draw_button(back_btn, "Back")

    def draw_scenarios(self):
        # Basic Scenario Sub-Menu drawing.
        container_width = int(self.SCREEN_WIDTH * 0.8)
        container_height = int(self.SCREEN_HEIGHT * 0.8)
        container_x = (self.SCREEN_WIDTH - container_width) // 2
        container_y = (self.SCREEN_HEIGHT - container_height) // 2
        pygame.draw.rect(self.screen, (160, 160, 160), (container_x, container_y, container_width, container_height))
        title_text = self.menu_font.render("Scenario Sub-Menu", True, (0, 0, 0))
        self.screen.blit(title_text, title_text.get_rect(center=(container_x + container_width//2, container_y + 40)))
        placeholder_text = self.info_font.render("List of scenarios will be here.", True, (0, 0, 0))
        self.screen.blit(placeholder_text, placeholder_text.get_rect(center=(container_x + container_width//2, container_y + container_height//2)))
        back_btn = pygame.Rect(0, 0, 150, 40)
        back_btn.center = (container_x + container_width // 2, container_y + container_height - 50)
        self.draw_button(back_btn, "Back")

    def draw_in_game(self):
        self.screen.fill((0, 0, 0))
        self.screen.blit(self.cached_scaled_map, (-self.camera_x, -self.camera_y))
        if self.selecting and self.selection_rect:
            overlay = pygame.Surface((self.selection_rect.width, self.selection_rect.height), pygame.SRCALPHA)
            overlay.fill((0, 255, 0, 50))
            self.screen.blit(overlay, (self.selection_rect.x, self.selection_rect.y))
            pygame.draw.rect(self.screen, (0, 255, 0), self.selection_rect, 2)
        top_bar_rect = pygame.Rect(0, 0, self.SCREEN_WIDTH, self.top_bar_height)
        pygame.draw.rect(self.screen, (70, 70, 70), top_bar_rect)
        fs_button_rect = pygame.Rect(self.SCREEN_WIDTH - 45, 5, 30, 30)
        pygame.draw.rect(self.screen, (150, 150, 150), fs_button_rect)
        pygame.draw.rect(self.screen, (0, 0, 0), fs_button_rect, 2)
        fs_text = self.button_font.render("FS", True, (0, 0, 0))
        self.screen.blit(fs_text, fs_text.get_rect(center=fs_button_rect.center))
        clock_bar_rect = pygame.Rect(self.SCREEN_WIDTH - 210, self.top_bar_height + 10, 200, 40)
        pygame.draw.rect(self.screen, (50, 50, 50), clock_bar_rect)
        pause_btn_rect = pygame.Rect(clock_bar_rect.x + 10, clock_bar_rect.y + 5, 30, 30)
        pygame.draw.rect(self.screen, (100, 100, 100), pause_btn_rect)
        pause_label = self.button_font.render("||" if not self.paused else ">", True, (0, 0, 0))
        self.screen.blit(pause_label, pause_label.get_rect(center=pause_btn_rect.center))
        date_str = self.sim_time.strftime("%B %d, %Y")
        date_text = self.button_font.render(date_str, True, (0, 0, 0))
        self.screen.blit(date_text, date_text.get_rect(midright=(clock_bar_rect.right - 10, clock_bar_rect.centery)))
        ui_bar_rect = pygame.Rect(self.SCREEN_WIDTH - 210, clock_bar_rect.bottom + 10, 200, 40)
        pygame.draw.rect(self.screen, (50, 50, 50), ui_bar_rect)
        minus_btn_rect = pygame.Rect(ui_bar_rect.x + 10, ui_bar_rect.y + 5, 30, 30)
        plus_btn_rect = pygame.Rect(ui_bar_rect.x + ui_bar_rect.width - 40, ui_bar_rect.y + 5, 30, 30)
        pygame.draw.rect(self.screen, (100, 100, 100), minus_btn_rect)
        pygame.draw.rect(self.screen, (100, 100, 100), plus_btn_rect)
        minus_label = self.button_font.render("-", True, (0, 0, 0))
        plus_label = self.button_font.render("+", True, (0, 0, 0))
        self.screen.blit(minus_label, minus_label.get_rect(center=minus_btn_rect.center))
        self.screen.blit(plus_label, plus_label.get_rect(center=plus_btn_rect.center))
        current_multiplier = self.multiplier_mapping[self.time_multiplier_state]
        multiplier_text = self.button_font.render(f"{current_multiplier}x", True, (0, 0, 0))
        self.screen.blit(multiplier_text, multiplier_text.get_rect(center=ui_bar_rect.center))

    def update_in_game(self, dt):
        if not self.paused:
            self.sim_time += timedelta(days=dt * self.multiplier_mapping[self.time_multiplier_state])
        keys = pygame.key.get_pressed()
        if keys[pygame.K_a]:
            self.camera_x -= self.PAN_SPEED
        if keys[pygame.K_d]:
            self.camera_x += self.PAN_SPEED
        if keys[pygame.K_w]:
            self.camera_y -= self.PAN_SPEED
        if keys[pygame.K_s]:
            self.camera_y += self.PAN_SPEED
        if self.zoom != self.last_zoom:
            scaled_width = int(self.map_image.get_width() * self.zoom)
            scaled_height = int(self.map_image.get_height() * self.zoom)
            self.cached_scaled_map = pygame.transform.scale(self.map_image, (scaled_width, scaled_height))
            self.last_zoom = self.zoom
        scaled_width = self.cached_scaled_map.get_width()
        scaled_height = self.cached_scaled_map.get_height()
        if scaled_width <= self.SCREEN_WIDTH:
            self.camera_x = (scaled_width - self.SCREEN_WIDTH) // 2
        else:
            self.camera_x = max(0, min(self.camera_x, scaled_width - self.SCREEN_WIDTH))
        if scaled_height <= self.SCREEN_HEIGHT:
            self.camera_y = (scaled_height - self.SCREEN_HEIGHT) // 2
        else:
            self.camera_y = max(0, min(self.camera_y, scaled_height - self.SCREEN_HEIGHT))

    def update(self, dt):
        if self.current_state == "in_game":
            self.update_in_game(dt)

    def draw(self):
        if self.current_state == "main_menu":
            self.draw_main_menu()
        elif self.current_state == "settings":
            self.draw_settings()
        elif self.current_state == "load_game":
            self.draw_load_game()
        elif self.current_state == "new_game":
            self.draw_new_game()
        elif self.current_state == "in_game":
            self.draw_in_game()
        elif self.current_state == "more_countries":
            self.draw_more_countries()
        elif self.current_state == "scenarios":
            self.draw_scenarios()

if __name__ == "__main__":
    game = RTSGame()
    game.run()
